import org.junit.Test;
import static org.junit.Assert.*;

public class SimpleCalculatorTest {

    @Test
    public void testAdd() {
        SimpleCalculator calculator = new SimpleCalculator();
        double result = calculator.add(5.5, 2.5);
        assertEquals(8.0, result, 0.0001); // delta is the maximum difference between expected and actual values
    }

    @Test
    public void testSubtract() {
        SimpleCalculator calculator = new SimpleCalculator();
        double result = calculator.subtract(5.5, 2.5);
        assertEquals(3.0, result, 0.0001);
    }

    @Test
    public void testMultiply() {
        SimpleCalculator calculator = new SimpleCalculator();
        double result = calculator.multiply(5.5, 2.5);
        assertEquals(13.75, result, 0.0001);
    }

    @Test
    public void testDivide() {
        SimpleCalculator calculator = new SimpleCalculator();
        double result = calculator.divide(5.5, 2.5);
        assertEquals(2.2, result, 0.0001);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDivideByZero() {
        SimpleCalculator calculator = new SimpleCalculator();
        calculator.divide(5.5, 0);
    }
}
