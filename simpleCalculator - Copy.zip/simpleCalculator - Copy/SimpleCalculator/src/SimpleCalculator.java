import java.util.Scanner;

public class SimpleCalculator {
    
    public double add(double num1, double num2) {
        return num1 + num2;
    }
    
    public double subtract(double num1, double num2) {
        return num1 - num2;
    }
    
    public double multiply(double num1, double num2) {
        return num1 * num2;
    }
    
    public double divide(double num1, double num2) {
        if (num2 == 0) {
            throw new IllegalArgumentException("Cannot divide by zero");
        }
        return num1 / num2;
    }
    
    public static void main(String[] args) {
        SimpleCalculator calculator = new SimpleCalculator();
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter first number: ");
        double num1 = scanner.nextDouble();
        
        System.out.print("Enter second number: ");
        double num2 = scanner.nextDouble();
        
        double result = calculator.add(num1, num2);
        System.out.println("Addition result: " + result);
        
        result = calculator.subtract(num1, num2);
        System.out.println("Subtraction result: " + result);
        
        result = calculator.multiply(num1, num2);
        System.out.println("Multiplication result: " + result);
        
        result = calculator.divide(num1, num2);
        System.out.println("Division result: " + result);
        
        scanner.close(); // close the scanner to avoid resource leak
    }
}
